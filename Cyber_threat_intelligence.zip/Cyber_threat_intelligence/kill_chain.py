def predict_kill_chain(intents):

    if not intents:
        return {}

    stage = "reconnaissance"

    if "credential_theft" in intents:
        stage = "delivery"

    if "system_compromise" in intents:
        stage = "exploitation"

    if "financial_extortion" in intents:
        stage = "actions_on_objective"

    return {"stage": stage}