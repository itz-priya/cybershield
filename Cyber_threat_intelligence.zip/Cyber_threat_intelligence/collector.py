import requests

API_KEY = ""

def collect_darkweb_data():

    url = "https://otx.alienvault.com/api/v1/pulses/subscribed"

    headers = {
        "X-OTX-API-KEY": API_KEY
    }

    texts = []

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()

        data = response.json()

        for pulse in data.get("results", []):
            texts.append(pulse.get("name", ""))

    except Exception as e:
        print("Collector error:", e)

    return texts