def analyze_behavior(text):

    if "ransomware" in text.lower():
        return "malware_behavior"

    if "exploit" in text.lower():
        return "exploit_behavior"

    return "unknown"