import pandas as pd

def analyze_behavior(threats):

    if not threats:
        return {}

    df = pd.DataFrame(threats, columns=["threat"])

    counts = df["threat"].value_counts()

    return counts.to_dict()