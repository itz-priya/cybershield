import requests
import socket
from stem import Signal
from stem.control import Controller

TOR_PROXY = "socks5h://127.0.0.1:9050"

proxies = {
    "http": TOR_PROXY,
    "https": TOR_PROXY
}


def is_tor_running():
    try:
        s = socket.create_connection(("127.0.0.1", 9050), timeout=5)
        s.close()
        return True
    except:
        return False


def renew_tor_ip(password=None):
    """
    Request a new Tor circuit
    """

    try:

        with Controller.from_port(port=9051) as controller:

            if password:
                controller.authenticate(password=password)
            else:
                controller.authenticate()

            controller.signal(Signal.NEWNYM)

        return True

    except Exception as e:
        print("Tor IP renewal failed:", e)
        return False


def tor_request(url, timeout=30):

    try:

        r = requests.get(
            url,
            proxies=proxies,
            timeout=timeout
        )

        return r.text

    except Exception as e:

        print("Tor request failed:", e)
        return None


def get_tor_ip():

    try:

        r = requests.get(
            "https://check.torproject.org/api/ip",
            proxies=proxies,
            timeout=10
        )

        return r.json()

    except:
        return None