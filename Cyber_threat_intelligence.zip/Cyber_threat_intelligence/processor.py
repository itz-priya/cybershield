import spacy
import pickle

nlp = spacy.load("en_core_web_sm")

model = pickle.load(open("threat_model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

KEYWORDS = [
    "malware",
    "ransomware",
    "phishing",
    "botnet",
    "exploit",
    "ddos"
]

def extract_threats(texts):

    threats = []

    for text in texts:

        doc = nlp(text.lower())

        for token in doc:
            if token.text in KEYWORDS:
                threats.append(token.text)

        X = vectorizer.transform([text])
        prediction = model.predict(X)[0]

        threats.append(prediction)

    return list(set(threats))