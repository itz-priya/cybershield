RULES = [
    {"keyword": "ransomware", "severity": "critical"},
    {"keyword": "remote code execution", "severity": "critical"},
    {"keyword": "privilege escalation", "severity": "high"},
    {"keyword": "sql injection", "severity": "high"},
    {"keyword": "exploit", "severity": "medium"},
]


def apply_rules(text):

    text = text.lower()

    for rule in RULES:
        if rule["keyword"] in text:
            return rule

    return None