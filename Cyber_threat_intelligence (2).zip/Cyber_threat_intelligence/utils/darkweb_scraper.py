import requests
from utils.config import TOR_PROXY

proxies = {
    "http": TOR_PROXY,
    "https": TOR_PROXY
}

onion_sites = [
    "http://exampleonion.onion"
]

def scrape_darkweb():

    data = []

    for url in onion_sites:

        try:

            r = requests.get(url, proxies=proxies, timeout=30)

            data.append({
                "source": "darkweb",
                "content": r.text[:500]
            })

        except:
            continue

    return data