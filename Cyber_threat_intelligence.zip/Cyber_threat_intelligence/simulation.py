import networkx as nx

def simulate_attack():

    G = nx.Graph()

    G.add_edges_from([
        ("Internet", "Firewall"),
        ("Firewall", "Server"),
        ("Server", "Database")
    ])

    try:
        attack_path = nx.shortest_path(G, "Internet", "Database")
    except:
        attack_path = []

    return {
        "attack_path": attack_path
    }