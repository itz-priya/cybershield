def recommend_defense(stage):

    mapping = {

        "delivery": "email filtering",
        "exploitation": "patch vulnerability",
        "impact": "isolate infected system"
    }

    return mapping.get(stage, "monitor system")