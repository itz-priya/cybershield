def predict_intent(behavior):

    intents = []

    if behavior.get("ransomware", 0) > 0:
        intents.append("financial_extortion")

    if behavior.get("phishing", 0) > 0:
        intents.append("credential_theft")

    if behavior.get("botnet", 0) > 0:
        intents.append("ddos_attack")

    if behavior.get("exploit", 0) > 0:
        intents.append("system_compromise")

    return intents