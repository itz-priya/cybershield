def map_stage(text):

    t = text.lower()

    if "phishing" in t:
        return "delivery"

    if "exploit" in t:
        return "exploitation"

    if "ransomware" in t:
        return "impact"

    return "unknown"