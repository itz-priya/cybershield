from neo4j import GraphDatabase

URI = "bolt://localhost:7687"
USERNAME = "neo4j"
PASSWORD = "password"

driver = GraphDatabase.driver(URI, auth=(USERNAME, PASSWORD))

def store_ioc_graph(threats):

    with driver.session() as session:

        for threat in threats:
            session.run(
                "MERGE (t:Threat {name:$name})",
                name=threat
            )

def close_connection():
    driver.close()