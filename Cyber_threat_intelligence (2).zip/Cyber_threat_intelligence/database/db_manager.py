from pymongo import MongoClient
from utils.config import MONGO_URI, DB_NAME

client = MongoClient(MONGO_URI)

db = client[DB_NAME]

threats = db["threats"]
alerts = db["alerts"]

def insert_threat(data):

    if not threats.find_one({"hash": data["hash"]}):
        threats.insert_one(data)

def insert_alert(alert):

    alerts.insert_one(alert)

def get_recent_alerts():

    return list(alerts.find().sort("_id", -1).limit(20))