from intelligence.collector import collect_all
from intelligence.processor import process
from intelligence.indicators import extract_all_indicators
from intelligence.kill_chain import map_stage

from analytics.behavior import analyze_behavior
from defense.rules_engine import apply_rules
from defense.defense import recommend_defense

from database.db_manager import insert_threat, insert_alert
from streaming.live_alerts import push_alert
from streaming.threat_streamer import push


def run():

    print("\n[THREATMATRIX] Starting Threat Intelligence Pipeline...\n")

    raw_data = collect_all()

    print(f"[Collector] Collected {len(raw_data)} raw threats")

    processed = process(raw_data)

    print(f"[Processor] Processed {len(processed)} threats\n")

    for threat in processed:

        text = threat["text"]

        print("\nProcessing threat:", text[:100])

        indicators = extract_all_indicators(text)

        behavior = analyze_behavior(text)

        stage = map_stage(text)

        rule = apply_rules(text)

        defense = recommend_defense(stage)

        threat["behavior"] = behavior
        threat["stage"] = stage
        threat["indicators"] = indicators
        threat["defense"] = defense

        insert_threat(threat)

        print("Behavior:", behavior)
        print("Kill Chain Stage:", stage)
        print("Indicators:", indicators)

        if rule:

            alert = {
                "text": text,
                "severity": rule["severity"]
            }

            insert_alert(alert)

            push_alert(alert)

            print("🚨 ALERT GENERATED:", rule["severity"])

        push(threat)

    print("\n[THREATMATRIX] Pipeline execution completed\n")


if __name__ == "__main__":
    run()