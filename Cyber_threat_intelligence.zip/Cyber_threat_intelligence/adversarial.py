def detect_adversarial(forecast):

    alerts = []

    probability = forecast.get("attack_probability", 0)

    if probability > 0.7:
        alerts.append("possible adversarial reconnaissance")

    return alerts