import pickle
import os

MODEL_PATH = "risk_model.pkl"

if os.path.exists(MODEL_PATH):
    model = pickle.load(open(MODEL_PATH, "rb"))
else:
    model = None

def forecast_attack(behavior):

    if model is None:
        return {"attack_probability": 0}

    features = [[
        behavior.get("ransomware", 0),
        behavior.get("phishing", 0),
        behavior.get("botnet", 0)
    ]]

    probability = model.predict_proba(features)[0][1]

    return {
        "attack_probability": float(probability)
    }