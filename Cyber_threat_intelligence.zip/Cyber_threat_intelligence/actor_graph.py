import networkx as nx

def build_actor_graph(threats):
    graph = nx.Graph()

    if not threats or len(threats) < 2:
        return graph

    for i in range(len(threats) - 1):
        graph.add_edge(threats[i], threats[i + 1])

    return graph