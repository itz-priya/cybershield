import queue

stream = queue.Queue()

def push(threat):

    stream.put(threat)

def get():

    if not stream.empty():

        return stream.get()