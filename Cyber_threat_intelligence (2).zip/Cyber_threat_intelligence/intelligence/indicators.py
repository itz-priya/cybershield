import re

ip_pattern = r"(?:[0-9]{1,3}\.){3}[0-9]{1,3}"
domain_pattern = r"\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b"
url_pattern = r"https?://[^\s]+"
hash_pattern = r"\b[A-Fa-f0-9]{32,64}\b"


def extract_ips(text):

    return re.findall(ip_pattern, text)

def extract_domains(text):

    domains = re.findall(domain_pattern, text)

    clean = []

    for d in domains:
        if "." in d and not d.endswith(".php"):
            clean.append(d)

    return list(set(clean))


def extract_urls(text):

    return re.findall(url_pattern, text)


def extract_hashes(text):

    return re.findall(hash_pattern, text)


def extract_all_indicators(text):

    return {

        "ips": extract_ips(text),
        "domains": extract_domains(text),
        "urls": extract_urls(text),
        "hashes": extract_hashes(text)

    }