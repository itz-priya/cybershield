import requests
from utils.config import RANSOMWARE_API

def fetch_ransomware():

    try:
        r = requests.get(RANSOMWARE_API)

        return r.json()

    except:
        return []