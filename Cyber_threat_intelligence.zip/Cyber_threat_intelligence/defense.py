def generate_defense(attack_forecast):

    defense_actions = {}

    probability = attack_forecast.get("attack_probability", 0)

    if probability > 0.7:
        defense_actions["action"] = "activate firewall block"

    elif probability > 0.4:
        defense_actions["action"] = "increase monitoring"

    else:
        defense_actions["action"] = "normal monitoring"

    return defense_actions