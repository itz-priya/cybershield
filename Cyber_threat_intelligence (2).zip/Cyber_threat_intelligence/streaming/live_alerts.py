alerts = []

def push_alert(alert):

    alerts.append(alert)

def get_alerts():

    return alerts[-20:]