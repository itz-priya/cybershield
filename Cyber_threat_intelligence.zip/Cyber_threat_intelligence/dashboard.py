import plotly.graph_objects as go

def create_threat_chart(behavior_analysis):

    labels = list(behavior_analysis.keys())
    values = list(behavior_analysis.values())

    fig = go.Figure(data=[go.Bar(x=labels, y=values)])

    fig.update_layout(
        title="Threat Behavior Analysis",
        xaxis_title="Threat Type",
        yaxis_title="Frequency"
    )

    return fig