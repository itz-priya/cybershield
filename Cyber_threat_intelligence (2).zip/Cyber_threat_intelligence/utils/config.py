import os

TOR_PROXY = "socks5h://127.0.0.1:9050"

MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "threatmatrix"

MODEL_PATH = "models/model.pkl"
LABEL_PATH = "models/labels.pkl"

CVE_API = "https://cve.circl.lu/api/last"

EXPLOIT_API = "https://gitlab.com/exploit-database/exploitdb/-/raw/main/files_exploits.csv"

RANSOMWARE_API = "https://mb-api.abuse.ch/api/v1/"