from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from fastapi.responses import FileResponse
import uuid

app = FastAPI(
    title="Cyber Threat Intelligence API",
    description="Backend API for CyberShield Threat Detection System",
    version="1.0.0"
)

# Allow frontend (Next.js) to access backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production use ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------
# Mock Threat Intelligence Data
# (Later this will come from scrapers / ML models)
# -------------------------------------------------

threats = [
    {
        "id": str(uuid.uuid4()),
        "risk": "CRITICAL",
        "source": "DarkWeb Forum",
        "title": "Zero-Day Exploit Discussion",
        "description": "Hackers discussing zero-day vulnerability in enterprise firewall.",
        "timestamp": datetime.utcnow().isoformat()
    },
    {
        "id": str(uuid.uuid4()),
        "risk": "HIGH",
        "source": "Exploit DB",
        "title": "New Ransomware Variant",
        "description": "New ransomware targeting healthcare organizations detected.",
        "timestamp": datetime.utcnow().isoformat()
    }
]

# -------------------------------------------------
# Root Endpoint
# ------------------------------------------------

@app.get("/")
def home():
    return {
        "message": "Cyber Threat Intelligence API Running",
        "status": "OK"
    }

# -------------------------------------------------
# Health Check
# -------------------------------------------------

@app.get("/health")
def health():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow()
    }

# -------------------------------------------------
# Get All Threats
# -------------------------------------------------

@app.get("/threats")
def get_threats():
    return {
        "count": len(threats),
        "data": threats
    }

# -------------------------------------------------
# Add New Threat
# -------------------------------------------------

@app.post("/threats")
def add_threat(threat: dict):
    threat["id"] = str(uuid.uuid4())
    threat["timestamp"] = datetime.utcnow().isoformat()
    threats.append(threat)

    return {
        "message": "Threat added successfully",
        "data": threat
    }

# -------------------------------------------------
# Delete All Threats
# -------------------------------------------------

@app.delete("/threats")
def clear_threats():
    threats.clear()
    return {"message": "All threats cleared"}


@app.get("/favicon.ico")
async def favicon():
    return FileResponse("favicon.ico")