import requests
from utils.config import CVE_API

def fetch_cve():

    try:
        r = requests.get(CVE_API, timeout=10)
        return r.json()

    except:
        return []