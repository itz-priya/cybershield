from feeds.cve_feed import fetch_cve
from feeds.exploit_feed import fetch_exploits
from feeds.ransomware import fetch_ransomware
from utils.darkweb_scraper import scrape_darkweb

def collect_all():

    data = []

    data += fetch_cve()
    data += fetch_exploits()
    data += fetch_ransomware()
    data += scrape_darkweb()

    return data