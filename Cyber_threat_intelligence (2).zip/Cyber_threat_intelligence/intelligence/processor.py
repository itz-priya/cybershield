import hashlib

def generate_hash(text):
    return hashlib.sha256(text.encode()).hexdigest()


def process(raw_data):

    processed = []

    for item in raw_data:

        try:

            if isinstance(item, dict):

                text = str(item)

                # extract CVE description if available
                if "containers" in item:

                    desc = item["containers"]["cna"]["descriptions"][0]["value"]

                    text = desc

            else:
                text = str(item)

            processed.append({
                "text": text,
                "hash": generate_hash(text)
            })

        except:
            continue

    return processed