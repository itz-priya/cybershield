import networkx as nx

ioc_graph = nx.Graph()

def add_ioc(ioc):

    ioc_graph.add_node(ioc)