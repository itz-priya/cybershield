import networkx as nx

graph = nx.Graph()

def add_actor(actor, malware):

    graph.add_node(actor)
    graph.add_node(malware)

    graph.add_edge(actor, malware)